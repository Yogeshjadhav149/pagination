import { Component,OnInit } from '@angular/core';
import { ApiService } from './services/api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'pagination';

  data: any;
  totalRecords: any;
  page: number = 1;
  constructor(private api: ApiService) { }
 
  ngOnInit(): void {

    // this.api.getdata().subscribe((result:any)=>{
    //   this.data=result;
    //   console.log(this.data);
    // })
  // this.getusers();
  }

  getusers=()=>{

    this.api.getdata().subscribe((data:any)=>{
      this.data=data.results;
      console.log(this.data);
      this.totalRecords=data.results.length;
    })

  }
  
}


